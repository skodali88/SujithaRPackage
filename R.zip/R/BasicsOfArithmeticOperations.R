#These are basic Arithmetic Operations in R

#Assigning values to a Variable
A <- 5
B <- 4

#Note that while performing and operation it is important to print the operation otherwise the operations is performed and saved but not displayed

#Addition
print(A+B)

#Subtraction
print(A-B)

#Multiplication
print(A*B)

#Division
print(A/B)
print(A%%B) #This prints the remainder

#Exponent
print(A^B)

#Mean
A <- c(1,3,4,5)
mean(a)

#Median
A <- c(1,3,4,5,1)
median(a)



