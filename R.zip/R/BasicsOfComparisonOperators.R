#These are the basic comparison operators in R

#Assigning values to a Variable
A <- 5
B <- 4

#Checks and prints out True or False)
A == B #Equal
A != B #Not Equal
A > B #Greater
A < B #Lesser
A >= B #Greater than or Equal
A <= B #Lesser than or Equal


