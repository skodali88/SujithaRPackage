#These are basic Logical Operators in R

#Assigning values to a Variable
A <- 5
B <- 4

#Checks and prints out True or False)

A&B #Element-wise Logical AND operator
A&&B #Logical AND operator - Returns TRUE if both statements are TRUE
A|B #Elementwise- Logical OR operator.
A||B #Logical OR operator. It returns TRUE if one of the statement is TRUE.
A!B #Logical NOT - returns FALSE if statement is TRUE


